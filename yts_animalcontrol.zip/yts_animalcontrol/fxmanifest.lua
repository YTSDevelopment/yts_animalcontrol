fx_version 'cerulean'
game 'gta5'

author 'YTS Development'
description 'yts_animalcontrol'
version '1.0.0'
lua54 'yes'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

dependencies {
    'es_extended',
    'esx_skin',
    'ox_target'
}