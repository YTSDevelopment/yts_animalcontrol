INSERT INTO `jobs` (`name`, `label`) VALUES ('animalcontrol', 'Animal Control');
INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) 
VALUES ('animalcontrol', 0, 'employee', 'Dog Catcher', 200, '{}', '{}');
